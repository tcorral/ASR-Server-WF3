/* */ 
module.exports = { "default": require("core-js/library/fn/object/is-sealed"), __esModule: true };