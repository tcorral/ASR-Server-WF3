/* */ 
module.exports = { "default": require("core-js/library/fn/function/part"), __esModule: true };