plugin-json
===========

[![CDNJS](https://img.shields.io/cdnjs/v/systemjs-plugin-json.svg)](https://cdnjs.com/libraries/systemjs-plugin-json)

JSON loader plugin

Testing this project
--------------------

```sh
npm test
```

browse to <http://localhost:3000/test.html> and open the browser's development console.
You should see the json object logged.
