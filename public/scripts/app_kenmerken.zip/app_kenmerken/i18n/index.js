import nl from './nl.json!';
import en from './en.json!';
export default {
    nl,
    en
}
