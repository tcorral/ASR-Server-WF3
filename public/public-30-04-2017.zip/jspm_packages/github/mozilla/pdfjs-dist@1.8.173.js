define(["github:mozilla/pdfjs-dist@1.8.173/build/pdf.js"], function(main) {
  return main;
});