define(["github:krasimir/EventBus@master/lib/eventbus.min.js"], function(main) {
  return main;
});