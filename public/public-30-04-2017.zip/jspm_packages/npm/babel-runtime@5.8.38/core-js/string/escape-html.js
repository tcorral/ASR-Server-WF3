/* */ 
module.exports = { "default": require("core-js/library/fn/string/escape-html"), __esModule: true };