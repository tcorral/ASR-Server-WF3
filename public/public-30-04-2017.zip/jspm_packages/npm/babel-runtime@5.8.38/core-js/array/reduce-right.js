/* */ 
module.exports = { "default": require("core-js/library/fn/array/reduce-right"), __esModule: true };