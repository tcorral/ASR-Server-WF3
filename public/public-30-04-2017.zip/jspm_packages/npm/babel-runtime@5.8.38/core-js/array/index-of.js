/* */ 
module.exports = { "default": require("core-js/library/fn/array/index-of"), __esModule: true };