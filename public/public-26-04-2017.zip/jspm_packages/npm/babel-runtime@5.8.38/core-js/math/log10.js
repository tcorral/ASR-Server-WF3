/* */ 
module.exports = { "default": require("core-js/library/fn/math/log10"), __esModule: true };