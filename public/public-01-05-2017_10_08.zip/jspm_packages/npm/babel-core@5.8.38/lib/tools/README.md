## Tools

> This directory is best browsed while listening to
> https://www.youtube.com/watch?v=hglVqACd1C8.

### Protect Babel

The protect script seen here is to throw errors if someone ever tries to
include internal babel files in their script. If you need something to be
exposed, you should ask for it, not try to hack your way into getting it.

### External Helpers

You'll also find the script for building the external helpers file, this is
the Babel "runtime" where all helper functions go instead of the top of a file.
